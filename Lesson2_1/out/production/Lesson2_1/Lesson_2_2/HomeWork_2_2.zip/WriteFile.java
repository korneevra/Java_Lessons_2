package Lesson_2_2;

import java.util.HashMap;

public interface WriteFile {

    public void writeFile(HashMap<String, Float> students, String fileName);
}
