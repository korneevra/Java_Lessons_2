package Lesson_2_5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        AttendanceService attendanceService = new AttendanceService();
        AttendanceView attendanceView = new AttendanceView();
        Presenter presenter = new Presenter(attendanceService, attendanceView);
        presenter.buttonClick();

        Student student = new Student("Ilia");
        Student student1 = new Student("Gosha");
        Student student3 = new Student("Ira");

        StudentBook studentBook = new StudentBook();
        studentBook.addStudent(student);
        student.setAttendance(LocalDate.of(2000, 10, 20), true);
        student.setAttendance(LocalDate.of(2000, 10, 21), false);
        student.setAttendance(LocalDate.of(2000, 10, 22), true);
        studentBook.addStudent(student1);
        student1.setAttendance(LocalDate.of(2000, 10, 20), true);
        student1.setAttendance(LocalDate.of(2000, 10, 21), true);
        student1.setAttendance(LocalDate.of(2000, 10, 22), true);
        studentBook.addStudent(student3);
        student1.setAttendance(LocalDate.of(2000, 10, 20), false);
        student1.setAttendance(LocalDate.of(2000, 10, 21), false);
        student1.setAttendance(LocalDate.of(2000, 10, 22), false);

//        System.out.println(studentBook.getStudent("qqq"));
//        List<Student> list = new ArrayList<>();
//        list.add(student1);
//        list.add(student);
//        System.out.println(list.indexOf(student1));
//        List<String> l = Arrays.asList("www","eee","qqq");
//        System.out.println(l.indexOf("eee"));



    }

}
