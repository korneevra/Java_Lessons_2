package Lesson_2_5;

import java.time.LocalDate;
import java.util.List;

public class AttendanceService {
    private StudentBook studentBook;
    private String dbFileName = "students.db";

    public AttendanceService() {
        this.studentBook = new StudentBook();
    }



    public void loadDB() {
        studentBook.bookFill("students.db");
    }
    public void loadDB(String fileName) {
        studentBook.bookFill(fileName);
    }

    public Student getStudent(String name) {
        return studentBook.getStudent(name);
    }

    public void addStudent(String name) {
        studentBook.addStudent(name);
    }

    public void addAttendance(String name, LocalDate date, Boolean att) {
        studentBook.addAttendance(name, date, att);
    }

    public List getStudentBook() {
        return studentBook.getStudentsBook();
    }

    public List getStudentPerCent() {
        return studentBook.getStudentsPerCent();
    }

    public List getAttendanceLow25() {
        return studentBook.getAttendanceLow25();
    }

    public List getIncreasingAtt() {
        return studentBook.getIncreasingAtt();
    }
}
