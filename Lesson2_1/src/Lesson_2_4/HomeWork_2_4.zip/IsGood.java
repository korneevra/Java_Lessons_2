package Lesson_2_4;

public interface IsGood<T> {

    boolean isGood(T item);
}
