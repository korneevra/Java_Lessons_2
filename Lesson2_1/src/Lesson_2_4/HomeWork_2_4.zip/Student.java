package Lesson_2_4;

public class Student {
    private String name;
    private int rate;

    public Student(String name, int rate) {
        this.name = name;
        this.rate = rate;
    }

    public String getName() {
        return name;
    }

    public int getRate() {
        return rate;
    }
}
