package Lesson_2_4;

public class IsEven implements IsGood {


    @Override
    public boolean isGood(Object item) {
        return (int) item % 2 == 0;
    }
}
