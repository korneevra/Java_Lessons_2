package Lesson_2_4;

public class BeginsWith implements IsGood {
    private String string;

    public BeginsWith(String string) {
        this.string = string;
    }

    @Override
    public boolean isGood(Object item) {
        return ((String) item).startsWith(string);
    }
}
