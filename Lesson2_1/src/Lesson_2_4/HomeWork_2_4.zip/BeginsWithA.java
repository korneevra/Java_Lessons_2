package Lesson_2_4;

public class BeginsWithA implements IsGood{
    @Override
    public boolean isGood(Object item) {
        return ((String) item).startsWith("A");
    }
}
