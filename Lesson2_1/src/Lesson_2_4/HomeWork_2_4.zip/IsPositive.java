package Lesson_2_4;

public class IsPositive implements IsGood{


    @Override
    public boolean isGood(Object item) {
        return (int)item >= 0;

    }
}
